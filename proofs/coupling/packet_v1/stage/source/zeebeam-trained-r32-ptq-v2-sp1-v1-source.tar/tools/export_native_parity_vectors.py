#!/usr/bin/env python3
"""Export frozen architecture tensors for independent native Rust parity.

The output contains the 72 reduced camera tensors, 72 reduced emission
tensors, recorded donor slots, the frozen report's 144 integer numerators, and
one full primary matched pair for the typed-root/inference guest. It loads only
the architecture-selection role. It neither recalibrates nor mutates the PTQ
artifact.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys


THIS = Path(__file__).resolve()
REPO = next(parent for parent in THIS.parents if (parent / "zeebeam-science").is_dir())
SCIENCE = REPO / "zeebeam-science"
sys.path.insert(0, str(SCIENCE / "src"))

V2_TOOL = SCIENCE / "tools/export_trained_r32_ptq_v2_parity.py"
SPEC = importlib.util.spec_from_file_location("frozen_ptq_v2_for_rust_vectors", V2_TOOL)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load frozen PTQ-v2 exporter")
V2 = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = V2
SPEC.loader.exec_module(V2)

import numpy as np
import torch

from zeebeam_science.compact_zk_resolution_ladder_candidate import (
    SOURCE_SIZE,
    reduce_primary_pair,
)
from zeebeam_science.pair_loader_candidate import CandidateNegativeSampler, CandidatePairLoader
from zeebeam_science.typed_tile_root_candidate import (
    CAMERA,
    EMISSION,
    TypedPreprocessTensor,
    TypedTileBindings,
    commit_typed_tile_root,
)


BLOB_SHA256 = "0188b5c0f4ea08e81940aef1a8cb303c00b24e7f8b7730a64bf5080d4030353a"
MANIFEST_SHA256 = "0a2cbe6992e1f1f0911b7ab6e09184bc96408dda0684657ec6c0a21125305290"
REPORT_SHA256 = "784bd57327fbec4a1ea509025b795c63ca8789bb6d6899fe6a42b831d9cdc347"
REPORT_SELF_SHA256 = "54b3f2a4d895ba97bd7397f80186698a3aed00b8ff701a179454f39b43976140"
VECTOR_MAGIC = b"ZBPARV2\x00"
EXPECTED_ROWS = 72
RUNG_SIZE = 32


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json(value: object) -> bytes:
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)
        + "\n"
    ).encode("ascii")


def write_new(path: Path, payload: bytes) -> None:
    if path.exists():
        raise RuntimeError(f"refusing to overwrite {path}")
    path.write_bytes(payload)


def export(output: Path) -> None:
    artifact = Path("[machine path redacted]")
    blob_path = artifact / "r32_fit_calibrated_ptq_v2.bin"
    manifest_path = artifact / "r32_fit_calibrated_ptq_v2_manifest.json"
    report_path = artifact / "r32_fit_calibrated_architecture_parity_v2.json"
    if sha256(blob_path) != BLOB_SHA256 or sha256(manifest_path) != MANIFEST_SHA256 or sha256(report_path) != REPORT_SHA256:
        raise RuntimeError("frozen PTQ-v2 artifact binding changed")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if report.get("report_sha256_without_self") != REPORT_SELF_SHA256:
        raise RuntimeError("frozen parity report self-hash changed")

    config, _ = V2.load_candidate_config(V2.CONFIG_PATH)
    result, commitments, _ = V2.V1.validate_parent_run(config)
    index = V2._build_index(result)
    sampler = CandidateNegativeSampler(index, seed=result["run_config"]["seed"])
    plan = sampler.far_derangement_plan(
        "architecture_selection", minimum_distance=result["run_config"]["minimum_distance"]
    )
    selections = [
        {
            "block_ordinal": item.block_ordinal,
            "anchor_chain_index": item.anchor_chain_index,
            "donor_chain_index": item.donor_chain_index,
        }
        for item in plan.selections
    ]
    if selections != result["architecture_selection_schedule"]["selections"]:
        raise RuntimeError("architecture schedule changed")
    rows = tuple(result["partition"]["evaluation_row_indices"])
    if len(rows) != EXPECTED_ROWS:
        raise RuntimeError("architecture row count changed")
    loader = CandidatePairLoader(index, output_size=SOURCE_SIZE)
    camera_primary, emission_primary, row_commitments = V2._load_primary_rows(
        loader=loader,
        rows=rows,
        commitments=commitments,
        role="architecture_selection",
    )
    camera, emission = reduce_primary_pair(camera_primary, emission_primary, rung_size=RUNG_SIZE)
    row_to_slot = {row: slot for slot, row in enumerate(rows)}
    donor_slots = [row_to_slot[item["donor_chain_index"]] for item in selections]

    records = report["evaluation"]["rows"]
    if len(records) != EXPECTED_ROWS:
        raise RuntimeError("parity row count changed")
    matched: list[int] = []
    crossed: list[int] = []
    for position, (selection, record) in enumerate(zip(selections, records, strict=True)):
        anchor = selection["anchor_chain_index"]
        donor = selection["donor_chain_index"]
        if (
            record["position"] != position
            or record["anchor_chain_index"] != anchor
            or record["donor_chain_index"] != donor
            or record["anchor_primary_pair_sha256"] != row_commitments[row_to_slot[anchor]]
            or record["donor_primary_pair_sha256"] != row_commitments[row_to_slot[donor]]
        ):
            raise RuntimeError(f"parity row binding changed at {position}")
        matched.append(record["integer"]["matched_numerator"])
        crossed.append(record["integer"]["crossed_numerator"])

    bindings = TypedTileBindings()
    primary_camera = camera_primary[0].contiguous().numpy()
    primary_emission = emission_primary[0].contiguous().numpy()
    typed = commit_typed_tile_root(
        TypedPreprocessTensor.from_values(CAMERA, np.ascontiguousarray(primary_camera), bindings),
        TypedPreprocessTensor.from_values(EMISSION, np.ascontiguousarray(primary_emission), bindings),
        bindings,
    )

    payload = bytearray(VECTOR_MAGIC)
    payload.extend(struct.pack("<I", EXPECTED_ROWS))
    payload.extend(camera.contiguous().numpy().tobytes(order="C"))
    payload.extend(emission.contiguous().numpy().tobytes(order="C"))
    payload.extend(struct.pack(f"<{EXPECTED_ROWS}I", *donor_slots))
    payload.extend(struct.pack(f"<{EXPECTED_ROWS}q", *matched))
    payload.extend(struct.pack(f"<{EXPECTED_ROWS}q", *crossed))
    payload.extend(primary_camera.tobytes(order="C"))
    payload.extend(primary_emission.tobytes(order="C"))

    output.mkdir(parents=True, exist_ok=True)
    vector_path = output / "architecture_r32_parity_v2.bin"
    vector_sha = hashlib.sha256(payload).hexdigest()
    manifest = {
        "schema": "zeebeam-trained-r32-native-parity-vectors/v1",
        "status": "development_only_native_parity_fixture",
        "source": {
            "blob_sha256": BLOB_SHA256,
            "blob_manifest_sha256": MANIFEST_SHA256,
            "parity_report_sha256": REPORT_SHA256,
            "parity_report_sha256_without_self": REPORT_SELF_SHA256,
            "architecture_schedule_sha256": plan.sha256(),
            "architecture_row_count": EXPECTED_ROWS,
            "verification_rows_loaded": False,
        },
        "format": {
            "magic_hex": VECTOR_MAGIC.hex(),
            "byte_order": "little",
            "camera": [EXPECTED_ROWS, 4, 32, 32],
            "emission": [EXPECTED_ROWS, 3, 32, 32],
            "donor_slots": [EXPECTED_ROWS],
            "matched_numerators": [EXPECTED_ROWS],
            "crossed_numerators": [EXPECTED_ROWS],
            "primary_camera": [4, 256, 256],
            "primary_emission": [3, 256, 256],
        },
        "first_primary_pair": {
            "position": 0,
            "anchor_chain_index": selections[0]["anchor_chain_index"],
            "primary_pair_sha256": row_commitments[0],
            "expected_numerator": matched[0],
            "typed_context_digest": typed.context_digest.hex(),
            "typed_root": typed.root_hex,
        },
        "vector": {
            "file": vector_path.name,
            "bytes": len(payload),
            "sha256": vector_sha,
        },
        "claim_boundary": "engineering_parity_and_guest_golden_vector_only",
    }
    manifest["manifest_sha256_without_self"] = hashlib.sha256(canonical_json(manifest)).hexdigest()
    write_new(vector_path, bytes(payload))
    write_new(output / "architecture_r32_parity_v2_manifest.json", canonical_json(manifest))
    print(json.dumps({"vector_sha256": vector_sha, "bytes": len(payload), "typed_root": typed.root_hex}, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    export(args.output.resolve())


if __name__ == "__main__":
    main()
