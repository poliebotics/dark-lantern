//! SP1 6.4.0 relation joining one private PREPROCESS_V1 primary pair to its
//! typed tile root and the frozen trained-r32 PTQ-v2 integer score.

#![no_main]
sp1_zkvm::entrypoint!(main);

use sha2::{Digest, Sha256};
use zeebeam_trained_r32_ptq_v2_model::{
    BlobModel, BLOB_SHA256, CAMERA_PRIMARY_BYTES, EMISSION_PRIMARY_BYTES,
};
use zeebeam_trained_r32_ptq_v2_relation::{decode_hex_32, public_values, typed_root};

const MODEL_BLOB: &[u8] = include_bytes!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../frozen/r32_fit_calibrated_ptq_v2.bin"
));

pub fn main() {
    let input = sp1_zkvm::io::read_vec();
    assert_eq!(
        input.len(),
        CAMERA_PRIMARY_BYTES + EMISSION_PRIMARY_BYTES,
        "private input must be one camera4/emission3 uint8 primary pair"
    );

    println!("cycle-tracker-report-start: model_binding");
    assert_eq!(
        Sha256::digest(MODEL_BLOB).as_slice(),
        decode_hex_32(BLOB_SHA256),
        "embedded PTQ-v2 blob SHA-256 differs"
    );
    let model = BlobModel::parse(MODEL_BLOB).expect("embedded PTQ-v2 blob differs");
    println!("cycle-tracker-report-end: model_binding");

    println!("cycle-tracker-report-start: typed_root");
    let (context, root) = typed_root(&input).expect("typed primary root failed");
    println!("cycle-tracker-report-end: typed_root");

    println!("cycle-tracker-report-start: reduction_and_inference");
    let score = model
        .score_primary_pair(
            &input[..CAMERA_PRIMARY_BYTES],
            &input[CAMERA_PRIMARY_BYTES..],
        )
        .expect("trained-r32 PTQ-v2 inference failed");
    println!("cycle-tracker-report-end: reduction_and_inference");

    println!("cycle-tracker-report-start: public_commitment");
    let public = public_values(score, &context, &root);
    sp1_zkvm::io::commit_slice(&public);
    println!("cycle-tracker-report-end: public_commitment");
}
