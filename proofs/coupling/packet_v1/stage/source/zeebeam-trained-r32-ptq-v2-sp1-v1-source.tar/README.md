---
version: 1.0
updated: 2026-08-23
status: historical-redacted-source-subset
author: BOSUN
---

**Publication status (5 September 2026).** Redacted source subset. `fixtures/architecture_r32_parity_v2.bin`, external toolchain files and build outputs named below are absent. The reproduction commands do not run from this archive as published. Its internal `SHA256SUMS` is a historical pre-redaction manifest; the repository-root ledger controls the archive bytes.

# ZeeBeam trained-r32 PTQ-v2 Rust and SP1 handoff

This isolated tree closes the engineering bridge from the frozen trained-r32
PTQ-v2 blob to exact Rust arithmetic and an SP1 6.4.0 guest. Native Rust
reproduces all 72 matched and 72 crossed architecture-selection numerators
bit-for-bit. The guest takes one private camera `uint8[4,256,256]` and emission
`uint8[3,256,256]`, computes the typed tile root, performs the exact 8-by-8
nearest-even reduction, runs the frozen trained integer discriminator, and
commits the root, score, and exact model bindings together.

The execute run passed with root
`8ee3eefa1027cc02d955b65f06840fe624ce07077f8d52f7e9e9f4eb309043b2`
and score numerator `56835791` over denominator `4`. It used 203,004,795 SP1
instructions and 5,344 ms of host execute time. The guest ELF is
`8a275c57b7b6d1db14103af0b530bb594ac772983937065bf3172d25b52234b6`.

The core prover was stopped to protect the shared desk. At the recorded
99-second point it held 82,768,584 KiB RSS, swap was full, and 5.2 GiB remained
available. No proof file was written. Groth16 and PLONK were not attempted.
The result is therefore an execute-verified proof relation and guest, with no
cryptographic proof or zero-knowledge proof yet.

The relation proves none of capture, chronology, physical pose, or reality by
itself. Its eventual proof would establish that one hidden preprocessed tensor
has the public typed root and receives the public frozen-model score. The
scientific meaning of that score remains the separately recorded discriminator
experiment. No scientific threshold is introduced here.

## Reproduction

```sh
STAGE=[machine path redacted]
TREE="$STAGE/zeebeam-trained-r32-ptq-v2-sp1-v1"
export RUSTUP_HOME="$STAGE/sp1_toolchain/rustup"
export PATH="$STAGE/sp1_toolchain/bin:$PATH"

cd "$TREE/program"
cargo prove build --locked

cd "$TREE"
cargo +1.97.1 fmt --all -- --check
cargo test --release --locked \
  -p zeebeam-trained-r32-ptq-v2-model \
  -p zeebeam-trained-r32-ptq-v2-native \
  -p zeebeam-trained-r32-ptq-v2-relation
cargo test --release --locked -p zeebeam-trained-r32-ptq-v2-script
cargo run --release --locked -p zeebeam-trained-r32-ptq-v2-native \
  --bin parity -- frozen/r32_fit_calibrated_ptq_v2.bin \
  fixtures/architecture_r32_parity_v2.bin
cargo run --release --locked -p zeebeam-trained-r32-ptq-v2-script -- \
  --mode execute
```

The first test command passes six tests. The host/SP1 command passes two. The
native parity executable checks 144 scores. Every command above uses only this
tree and the shared frozen SP1 toolchain.

## Frozen evidence

`results/native_parity_results.json` records the 144-score parity.
`results/execute_results.json` records the joined guest execution.
`results/core_attempt.json` records the stopped proof attempt and explicit
proof absence. `SHA256SUMS` binds the handoff last.

## Log

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-23 | BOSUN | Froze native bit-exact parity, the joined SP1 execute result, and the memory-bounded core attempt. |
