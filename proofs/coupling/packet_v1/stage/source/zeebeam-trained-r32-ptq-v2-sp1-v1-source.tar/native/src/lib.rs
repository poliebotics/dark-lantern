use sha2::{Digest, Sha256};
use zeebeam_trained_r32_ptq_v2_model::{
    CAMERA_PRIMARY_BYTES, CAMERA_REDUCED_BYTES, EMISSION_PRIMARY_BYTES, EMISSION_REDUCED_BYTES,
};

pub const VECTOR_MAGIC: &[u8; 8] = b"ZBPARV2\0";
pub const EXPECTED_ROWS: usize = 72;
pub const VECTOR_SHA256: &str = "7f46d1a239025ec9942fefd75adc07b87aeee92928a0db2c5b1ec949397a8c33";
pub const VECTOR_MANIFEST_SHA256: &str =
    "b162fcdcd575979706eae6382e131bbc7dfde475efaa7a0c2d04e63da0929253";

pub struct ParityVectors<'a> {
    pub camera: &'a [u8],
    pub emission: &'a [u8],
    pub donor_slots: Vec<usize>,
    pub matched_numerators: Vec<i64>,
    pub crossed_numerators: Vec<i64>,
    pub primary_camera: &'a [u8],
    pub primary_emission: &'a [u8],
}

impl<'a> ParityVectors<'a> {
    pub fn parse(bytes: &'a [u8]) -> Result<Self, &'static str> {
        if bytes.len() < 12 || &bytes[..8] != VECTOR_MAGIC {
            return Err("parity vector header differs");
        }
        let rows = u32::from_le_bytes(bytes[8..12].try_into().unwrap()) as usize;
        if rows != EXPECTED_ROWS {
            return Err("parity vector row count differs");
        }
        let camera_bytes = rows * CAMERA_REDUCED_BYTES;
        let emission_bytes = rows * EMISSION_REDUCED_BYTES;
        let expected = 12
            + camera_bytes
            + emission_bytes
            + rows * 4
            + rows * 8
            + rows * 8
            + CAMERA_PRIMARY_BYTES
            + EMISSION_PRIMARY_BYTES;
        if bytes.len() != expected {
            return Err("parity vector length differs");
        }
        let mut cursor = 12;
        let camera = &bytes[cursor..cursor + camera_bytes];
        cursor += camera_bytes;
        let emission = &bytes[cursor..cursor + emission_bytes];
        cursor += emission_bytes;
        let donor_slots = (0..rows)
            .map(|index| {
                let start = cursor + index * 4;
                u32::from_le_bytes(bytes[start..start + 4].try_into().unwrap()) as usize
            })
            .collect::<Vec<_>>();
        cursor += rows * 4;
        let matched_numerators = read_i64_vector(bytes, cursor, rows);
        cursor += rows * 8;
        let crossed_numerators = read_i64_vector(bytes, cursor, rows);
        cursor += rows * 8;
        let primary_camera = &bytes[cursor..cursor + CAMERA_PRIMARY_BYTES];
        cursor += CAMERA_PRIMARY_BYTES;
        let primary_emission = &bytes[cursor..cursor + EMISSION_PRIMARY_BYTES];
        if donor_slots.iter().any(|slot| *slot >= rows) {
            return Err("parity donor slot escaped architecture rows");
        }
        Ok(Self {
            camera,
            emission,
            donor_slots,
            matched_numerators,
            crossed_numerators,
            primary_camera,
            primary_emission,
        })
    }

    pub fn camera_row(&self, row: usize) -> &[u8] {
        let start = row * CAMERA_REDUCED_BYTES;
        &self.camera[start..start + CAMERA_REDUCED_BYTES]
    }

    pub fn emission_row(&self, row: usize) -> &[u8] {
        let start = row * EMISSION_REDUCED_BYTES;
        &self.emission[start..start + EMISSION_REDUCED_BYTES]
    }
}

fn read_i64_vector(bytes: &[u8], offset: usize, count: usize) -> Vec<i64> {
    (0..count)
        .map(|index| {
            let start = offset + index * 8;
            i64::from_le_bytes(bytes[start..start + 8].try_into().unwrap())
        })
        .collect()
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
