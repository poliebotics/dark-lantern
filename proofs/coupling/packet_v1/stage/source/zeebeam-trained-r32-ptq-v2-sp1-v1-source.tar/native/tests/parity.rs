use zeebeam_trained_r32_ptq_v2_model::{BlobModel, BLOB_SHA256};
use zeebeam_trained_r32_ptq_v2_native::{sha256_hex, ParityVectors, EXPECTED_ROWS, VECTOR_SHA256};

const BLOB: &[u8] = include_bytes!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../frozen/r32_fit_calibrated_ptq_v2.bin"
));
const VECTORS: &[u8] = include_bytes!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../fixtures/architecture_r32_parity_v2.bin"
));

#[test]
fn all_144_architecture_scores_match_python_bit_for_bit() {
    assert_eq!(sha256_hex(BLOB), BLOB_SHA256);
    assert_eq!(sha256_hex(VECTORS), VECTOR_SHA256);
    let model = BlobModel::parse(BLOB).unwrap();
    let vectors = ParityVectors::parse(VECTORS).unwrap();
    for row in 0..EXPECTED_ROWS {
        assert_eq!(
            model
                .score_reduced_pair(vectors.camera_row(row), vectors.emission_row(row))
                .unwrap(),
            vectors.matched_numerators[row],
            "matched row {row}"
        );
        assert_eq!(
            model
                .score_reduced_pair(
                    vectors.camera_row(row),
                    vectors.emission_row(vectors.donor_slots[row]),
                )
                .unwrap(),
            vectors.crossed_numerators[row],
            "crossed row {row}"
        );
    }
}

#[test]
fn primary_reduction_and_inference_match_first_python_score() {
    let model = BlobModel::parse(BLOB).unwrap();
    let vectors = ParityVectors::parse(VECTORS).unwrap();
    assert_eq!(
        model
            .score_primary_pair(vectors.primary_camera, vectors.primary_emission)
            .unwrap(),
        vectors.matched_numerators[0]
    );
}

#[test]
fn vector_tampering_changes_or_rejects_the_relation() {
    let model = BlobModel::parse(BLOB).unwrap();
    let vectors = ParityVectors::parse(VECTORS).unwrap();
    let expected = vectors.matched_numerators[0];
    let mut camera = vectors.camera_row(0).to_vec();
    camera[0] ^= 1;
    let changed = model
        .score_reduced_pair(&camera, vectors.emission_row(0))
        .unwrap();
    assert_ne!(changed, expected);
}
